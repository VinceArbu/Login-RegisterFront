import { users } from './data.js';

// register
document.getElementById("registerForm").addEventListener("submit", function(event) {
    event.preventDefault();

    
});